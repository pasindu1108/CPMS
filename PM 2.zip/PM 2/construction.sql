-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 18, 2020 at 06:00 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `construction`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendence`
--

CREATE TABLE `attendence` (
  `RecordID` int(11) NOT NULL,
  `EmployeeID` varchar(255) NOT NULL,
  `PID` varchar(255) DEFAULT NULL,
  `Date` varchar(255) DEFAULT NULL,
  `Intime` varchar(255) DEFAULT NULL,
  `Outtime` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attendence`
--

INSERT INTO `attendence` (`RecordID`, `EmployeeID`, `PID`, `Date`, `Intime`, `Outtime`) VALUES
(1, 'EMP1', NULL, 'uuyyyyyy', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `CID` varchar(255) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `Contact` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`CID`, `Name`, `Address`, `Contact`, `Email`, `Status`) VALUES
('CID1', NULL, NULL, NULL, NULL, NULL),
('CID2', 'pasindu', 'nugegoda', '123456', 'erty', 1);

-- --------------------------------------------------------

--
-- Table structure for table `empleaves`
--

CREATE TABLE `empleaves` (
  `RecordID` int(11) NOT NULL,
  `EmployeeID` varchar(255) DEFAULT NULL,
  `Date` varchar(50) DEFAULT NULL,
  `Leavetype` varchar(50) DEFAULT NULL,
  `Duration` varchar(50) DEFAULT NULL,
  `Description` varchar(50) DEFAULT NULL,
  `Approvel` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `empleaves`
--

INSERT INTO `empleaves` (`RecordID`, `EmployeeID`, `Date`, `Leavetype`, `Duration`, `Description`, `Approvel`) VALUES
(1, 'EMP1', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `EmployeeID` varchar(225) NOT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `MaritalStatus` varchar(50) DEFAULT NULL,
  `HouseNo` varchar(50) DEFAULT NULL,
  `Street` varchar(50) DEFAULT NULL,
  `City` varchar(50) DEFAULT NULL,
  `Gender` varchar(50) DEFAULT NULL,
  `ContactNo` varchar(50) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `Position` varchar(50) DEFAULT NULL,
  `BasicSalary` int(11) DEFAULT NULL,
  `Image` blob DEFAULT NULL,
  `Status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`EmployeeID`, `FirstName`, `LastName`, `MaritalStatus`, `HouseNo`, `Street`, `City`, `Gender`, `ContactNo`, `Email`, `Position`, `BasicSalary`, `Image`, `Status`) VALUES
('EMP1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1),
('EMP2', 'qqqqqqqq', 'qqqqqq', 'eeeeeeeeeeee', 'married', '123', 'qqqqqqqq', '21111', 'male', 'ssssss', 'Labourer', 123, NULL, 1),
('EMP3', 'qqqqqqqqq', 'qqqqqqqq', 'married', '12', 'aaaaaa', 'aaaaaaaa', 'male', '133', 'sssssssss', 'Labourer', 1234, NULL, 0),
('EMP4', 'eeeeee', 'wwwwwwww', 'married', '1', 'wwwww', 'wwwww', 'male', '1234', 'ssss', 'Labourer', 1234, 0x89504e470d0a1a0a0000000d49484452000000640000006408000000005589ca88000014f84944415478dab59a595a253db2657dfe830282008236e889005c32f5bd6c7b73dccf6b0da0eaab9b99f7cf11e8418dadbdb686cbc9eacf3c4a356afae0e61f73764f3ae54b17d287697cd34a21c4f48562ff36e64713faadc578d7bbff5128bfe8d2efc414fe92aee742c65725f0aa55bc47378f5929e3c738b0376a275d56f8ccda971904682b8e52b49da3c404b92262d2254dada7354ebc83c21cbc9d9d531c518e0cda63f39b0e7a8d8d5181bd653509cb48c60e711200fdf6c1df78e72e44c43b18e788eda1eb70956213ba82d0f2a51356a8646e9a11d74587b3deda2bd8dcab8c5f6d146fc1d02bf7a0989a0a265e7b9b65aee10503c436221c00ec3939b6d66f2df63929b1744f1c835b7b134b809f1035f7d80e196161d8b9bab6c3e2e8b3989069f6deec5dd3ce26cf4eb8cd18acadf5c90ea7f0f427577eaf8dde7a6a9fb2e2a507fe9995197dd35f52b88fc4fd1a35bdc4185f73cb7fba09c67378a45eff3a98bfcd64c9bdff252ddf5c489f8ae8af69f19cb84bdbdc70e41040d5aca1b415bdcdb9d9831165d6bacf8ee98831afbd08b818a7a4ed817b4555d8726adb14b113c4246d9ab4cd137a5ad0305322e831c0e5b6fa10861847642b47d83f11e2ba4f785594cf32c9d38ea8619529c4974dc52f41d678e5b5abe15de87a2ab3fad3a5ba29225d15049963ba32501f0af68c5abfb28a3e23c2b51dac3d8eae6f5e16e4a40fdd8963a8844a02312946d2881e9b09190a9e23aba34cadc79817cae3164bdc0cfc9a75d851cc8e5a51859abd8ec722f322518e34dc88804be5e249135ea2e38781bee50a5d759302fe67c95596da7ee69e3e9bac2af52029ab5fddb7ab26c57d49fc6d505f528c4f29b7b7dacde3e4f977a0feb73afcaacd0c6be7b60694593a9e51cbd41c0e5ecb35db11b2b929b83c837108a35f8bb2b333756f8ed74a800b7155294f368535187f08464e3563d504202b9442ab8b62687cc2c25e53eb1a09cf02f634405fb8387e09cfd421afa1ada8c01fddf09f9dc541944dc486dcf211394eb5ca355238f4e68f88e00240645a12d2e2d91eabc09e8a3e86a6f752f506e53616ccd6d0d6811551ec56845d2bb78c4dcc8c7e94c3970bf2d4937e6d84a7d4e34d607cc5483f4bee57cac677edd3b7e0f0b357be349379b2297da4a69e1ac4336a7f8b54fef45aefb3959735d0585c165e3a990c5f9374d4b21e36a1f8d88d3ada182085da7c52e8c6afde87adf73c97a68e2a844d59b57bb29b7298466166e4b251b69b1ed5667a5f93075c968b8d15887410c6efba016352833267b12ae1107ea7b10a87f0dd7579cca0dfae887b72e6453473eafcf4e59af91d814781f25314f99422c610f8028cdfaee005b19216f98c53fe63342ed8f53f4d5af283288bd2614f6e9cc0b4f4ec8f5e97bde6be936728d9e62ecaea14a03a2f35d306346ebacf3da609c9ccdddba5d4b8b9ee0e49d509c0e67ddf21183638c6f083aa790da5bda1b7fbdcec1f23ca83d6fdde31298cf9ad1771e562bc4dda7e70af1755e12ba7f639454882b89536dd6a9b6fd0d3331a1e28d1951ec385cbedcd877042691c0e4ea44544b952959ba2b61bc2d2525eb5b7070afd18b5584b51681e5be288c49625ecd4d91c8aa639772cc53a0484a30d8ea1f552bb39586410d10eeb86ce9f29e0c34b271cea876d4e57afcf52b62746b67b1bdc9b03530de3432aead639f317cd89544969179e924aafcea6c71ccc430de687add9244d44c817ba94f3ece209069126d65884f30751e4a46203a9b2b1c8b31471f1b54c963c7217070fb792e9ec52da43c2eca077ddfae4ea3479998f54fbb1a83c47c48d8459987008bd1dccf0ab4bbeae358e50e647f3b83315e72de0de923d973d9d9988cf51d2930eea3d93fa0a3d3e59d897c04678e4cfaedc63e956ca282e732f7735d90b55d50f2bdcadb4f142671e8eb660b64cb0b143a2cf45284655b0464faccb41913b0491d6d4fbae7ddf8d291c9a41360c06e63108860c53300d25fac5f97e8c9657c4c855146895079d2f5416dad720228d3435f9d8c82b6d71ad895e72c61fa7830c39dca08ad754f257f0f6545affd66b3e25f6940a8c51fe141c7e4baad72994cf8cfee972bba946fcf143f590294fa3919bb361ce0e3b6a609f0aac7353459b395540bb2526b56467d790c3e46b98a4ad2b920608abd2e540d92d028416306b0664c3524b4118ce264b5f5de1d5f6f4d346a5eb68151bf9e4641a8dd4efdeaa3715ed4574f694b85d201859a47f439127b6db07a0bd39633e4b1def796a37e8f9421af5ac183f9059452f070ed07071dc84e7bd434ed076afc04137303c1d72e5436db4f6d43659b1f6c0c8ca6cbee94d0a7748dc27d4b4c618d7dcf2a19b70f41c16eaf5e0600ecde4a1b40ba8f0d894bd604fb74d396d4671ed913f1ae5dbaec78b6efa989227e5f28f68e35f423cafc23cb06ea4c674698c14907ab4821ed0e8a3b0fd2b73bfc9525fb9a26eedd0fddc19ccca2e4e626a46024c932a40021d9de6dd163e7adf0fadb4058e17ee98b38c8b475e65254498bd2abbf748b320b137c8b5455e6dc19c5cdcd2f0dfb8171fa26495223d56ea7f058dc35ea498baf547b43c1bd30e7574fbd4ecb167c5464530e43133162f311580ad94506490a136952c8ba2a17b87d70cd53b47a499274ca5c5d58e0a32d6a1980b0097e8e292d17f29d8e740f24435ffa24cffe5937f08ad7fe7503e15d46368ea56b13fb74dddc18c67c6e3bd347ab35d9fa86ebe7b4a0f50ee4d46fb54094f54c5b51f9cd9a8b8cda5040ad853775325b3f44940c9343b9f908bd9c89a0d911763d3c2842545306c03acdabb6a13d001ea47e3d4aab39ead2940c762a6040c1f2de6dbf1bf3b1f07441d9033a185be448b29059ed8636d5d4da1f489656495fbc1d534295521ad98acb48bd2792fa2ac4811a1d25605b1778a5d305c8242e8691e2d768a7df84fd8b6352310cf6b4eca299285dd63413eb38c8fc6e2cbe5729da5380d01df5eba333194be951017a37992ce1c5233475fd51c6240d771ad90934ef54831b32ed883a7c9c98054260ea41722cdf07a49ba1facf733c3ee15992bd26a835985ca3b8627a9e5651445c5e64fb3f41f2cc26f5393d0052698f45d1a932fb8f7bedd82ec8fc8e1b466755a18cf3aabcb2cf050033fd108d364f8248f2b0b734594de32eaad0e188e8ee3dee15719c38c9cb8925e60f8a02cb6488e496083cc5be43215f8d5c5b616569303e6aae50ee8d90b7330c982281f202214304f36ef809d6078e8e95d237c6a2e7f75c385fb6fb0f1f0dfca8942a2bb3c792d173d5c8e49fd329249ea7e23c8ab46e5836dfd91bb7d935adf16e56ebaa23b27ca2fd3c2656cf1222a3c956ede43b067d1d94b55e8c1d6f0c3abfcedc0cf2239a9114e9d2f2745da61824d0b1b9e91dba65c3874cb8842adbdb843b20a55c94938cb362a642e5c329648e140bd328d7e56d22de6ffcfa18396cf3afa5390ba139c1eb33697cd41b526fff61894b3f51ac67dc3c927edf5b794fe4732b8f59c74f7fdd99bf266ba94a6d62786fa45cd2b67aaa61694b77443b2bfc8e19fe65ed32669b0935107a8742438f0f018d01fa493a7a5d8cb520c5557dec9970fa5d29f58c757a7e88ec85f19af2e11d263905ee9c95eb53cfec0a87f166e0f21e7bba8d39b76e1b598266d2b1f407c6928b7b5f170885dcd4c6945365340d95a094b347a77d2a1a406f88a10e2a2ba5e52059c4e07505c852e47040febe4225339ca40084490f088496fc5fad93326ae1874fa22c4d71eed23a33d47a28fdcf5a58de5caa77eca81c6caea7a32f136a5f2d254fc8288547b7ea652c75afd9b95ea6fa0feee32df4bc72f86cdb974f8ca9a2e4da9bfa64115c04ab4ae27456d4130536b1323d22127cc8af8c02e1c90e5c4281b8b36e5625629c412d067e9249762518ad9ab2b2bf972502a1d621d57a76826f230c33d389e24c75708e2ce17f1475af5dc145d94cea739c8d318fddf62edb9a7fc2daa2797e9ba4bf79238bcc23ba3597f75e7fe4ec6ffc8a0bf1de532fba863a71313f9274a18c04a6d5dc663f27c842b5bcc9695914b553c238475ac3c23f44d97b082c25c848333899b11b39fdadc4c5880c028c445c635a22f81d59111e682748c15434ba7d58967ebca0544f916b1fdc82d6be47853ab7c8d14de7bf3061167053817991e13d2b367abaac0988ad6a16959aafe82725f2cf8d41afaeac00ba2202b02e9c18b55fab28b105013a3008b49fdd01873819b7d7347b272e1200e59890323222bb50af843e08811d3264383879e603428e515d52120acc1e220523ae4e129a6fc996bff15262f42a0b156a74c6dd799f9bb57ba94d93da6a67e52355f914876d87f37fb0f6c2203256cad988385671b3b771139067b1051fc13f965a0f2215218c933b996449793ac456813e9495a75569c1d93c6d8a95c2b406bf413c5f8360ab731d09950ed2129331a9f1e7c68df3d878fa6701942bbb48aefc9b64b3780b6003f9125ee494e11ad4b8a082aafa4dad263fcdfbfd3c37fe2141fa5f03f756a3f11d377b441a2c567a2f2dab5ba8d45dfa72e64a0fec9ca1813ed804440a8e65083df95716bf696a59208a24dae0b480320f4d5393da90038d8a3d46dea49cfa9d18e18271ffd1a1d0ea18c3b264caea5396ab3c48ed5621cfe591f74ae4cf96326f759b3b96c1a6fdec50b1a924200d6eeec46266d93d090c94f3ea9b5980e6bda3172804d6127c435623cdaa677ab7853cdece872a70e389591b59f4cd1c78e384d49ed64c3b1443de741155b3f99c375e8f606a3fbee5e7e504e57a5bbd329d4735de94cc6f453205da9e85537e14d29dc8f912f2699bec618df03e59316cb53337848593f32ca2fa0fed5555c78af8783a500ddd39e5285cd62ebe4969ae82882988b8a0725dc1681456a8928ca3136cf59fa038bb0989a765d700c266da5f1ee0b66efdb04b21c3970cd8a0b63209c58695f9cb66f16fd25a291a774aef5f85bb9fc997d7814944e9ccdef35bb6b1fd59da4fe5b49baac5a9e1a9bde8b186f6b2fef2dc8fb9efcbbf1f892423d23c75fa1f26319c8a27b86e50c6dfd12a3d8944c0c8139775e611a428a8bd37af6d419a23142390258931b27ebdb16bb5f95889b27b90497b626c2026f8f518f5b6c65c5f043c4785f8bbd214f6f5dd407b87c6ebabc4f897f27f87b68be6addddd7c93cc88cf3daf1a1b27f42ece7c24449288fbd95eb62712f6cfc965d3c8b186e8a8827b04579cbc36c14a04b3efa2ce18bdb091a5600a2618f521f21f331c2a124bbf5949789b153f08bb77e764a2c28d841589aef083a2d8df501c0969563cb6a35b60d32eae4d9c095af98ed8932f2a92abe47082f63e53b84fead4b780785bb22dcb933e9b41971e7a776df4c7806c2290a9d16195f23fa6360a519e1ae20a9587125b21cd310fb4c322e2ef54d8470f4168b1efbd24ade43e4ddfa3a356002fc2a0c560a7e36bd83c0c8ceb1eb06c86debceb2947dcec64326bd78012827f61432ccf0564cff694d5391c32f9b8220c4d78851dba6c92afe56cd10ba24eaf8e554becadadf9aa25547bc9e9252648329513fe4026d729382e927a2fc8c304fd1e7579be2b0d42257dbed51b8760ca9c035b78b508f3ad97fca4f0edddd08294797cdbd96e92a7a2149b9534ee15d1bf5e980cf26eb770cb8b3d528e33a3919afbcee67d2cb1703fbc009a3eff1de94fcfff680c3ffdce330a571b6391fb23373548ea9074852072dc564533988d11e7a295b906e4b3ec3a3b150f198a3592a87030fbfc074ad0a2e13483bcdca16d6def73fadb447387ee28e872ce36f8ffc222bfd8a30b22a4b3dd29d20410df2b5457eb7050fc9c5af54f8c23a285ff519802befc580dcd3d664dd530f3b6585ee1b9a147349bc19d435c5b8a4dcd6dacd32795e02f54375406d6665ee7b25cdd985b52942356d21e21db6cd418a9974da0871f8df7688a9dc45d77eb58cf342ea13b19d07e4975ae49bedd608d77418feef75d71eedc2684b243ae4ae6163814f9d39d056594d9389534a656d2a6e1071af3d2f54ea56ab5fad548740fde032cfd2f16ad8400e3f7d3323a9726254fe10de5c82f447867f97da7f3890d6da9e408a2f703cd313ce32a271babcd8d65ff3bfd6b70effa957dcb9f70369b9ba90364574302d82b8efb6b9450a0f9d1a10d3166d18a0ef60a71fbab93169ffd2082a46fb107d7e76288f65849e60ee5a0acfdac4e78e7c8b113735e2c4f44966456f32d399e87806ec4f1412aaa9e726e876f2ea01ae3e96a11bc0c685a440f309a69b3979bfb4ded7501aa0c2d294057b9a9a7247338ac9231f1ae5a9eb11ddf42d25bf2b9739da782044546166d66d5763823172c7f09c03bd8d2d7ec466c8a77c19181f06f853753d51de5f45941f394a5d40571df9ad737b0d28bfa5e37bd472d31cfe782d5fb21d7fc9e66e82cb7760fc0da37f2dcade395387c934352bc5dc65dab4f61b9c3a66d716c404aed341b15cab6b9b567d0778268ce81a53af7d25a5260ad88d6ec8dac3250f40cd7d94abb3fa50e1d0ac1ea47912cdde76a17e18681d7aba75da5c867f72af8654e6e81a5a060aa90db12120ffb36ff3f0550a28a6f6dfe4af81adb4abd376b5e86b44db3d25683d2ecae52dfbb0084addd9bcd6ec261fd524a92f4a12aa966c6c3a14314eb597430b72eec9afc66393422dc811a1f252580ed25c44c552224b447f06570c84fd2149fd342a936aead50af1a1a51e3bf92b56eabbffbb5c3020cc69acbb43d8ba2e4b06cdae88999c594533ecfcb4b96696082c0205a2c825456c2130c0985dc18a58772d3273ca07a30176fdd0a4dd7da853cd6d12c37751e692d12f5a2a867cbbcabe6bd2edb6c39e12f3b90ce206a68fb9e23fed5a86d924b119e1e6a9b9cd84784410c742e220635ad0c3c20a3b823b2061a9d09c252fb91a40f1dc6b83859fabad6bb302c5e4add5b24ad0a4296d3505249683c195e5aa50f517041ea8e4bf5cea17e5feda9afc83d41f99f285e9fe4b3779e24a1abbc19f94e2bf9e9b07650f1e793735addad2d28ada720b4b80e1da26ee148e5661eb1110b91c65a23524891ae51c3d03450391b7c66db54a1d6bcd2b7c9c7ceb87eaa739d5ca75f877e6c27f3a43878d545e33121cd454234daafb5d5b5e8db6738c91bb92eb08b1fbdcf704b3e99096e834bca74dfe6bff770685d3d2c55393f933036fd1d6bf32c5f350faa7079e218b0489770a8952f2d2a29ee2df75c943712b55b941f6b51bbba782834f38c07ad8e421ab98276b164b741cd137d8ca51e825523f28a37674b5a532c137bdfa0ee866375801664210f6687a5feb70a34ab946751f99fc7b51eab5c67a929c3a7744f7daf80b85f012827c809e6e74cb2712e32515fef421bfb9a85fb2768fa9982fb6eda300cfa9e1c3d6263898c76ead1a5d1ffe793671d8b226985231b976c8460f79fcf4d44619f57b50f1dc8972c1ffb4031b9a3f3ad3505c9fd37f2bd3ff1f152bffc62dcc07700000000049454e44ae426082, 1),
('EMP5', 'trrrrrrr', 'rrrrrrrr', 'eeeee', 'married', '324', 'eeeee', '123', 'male', 'eeee', 'Labourer', 2134, NULL, 1),
('EMP6', 'Pasindu', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Supervisor', NULL, NULL, 1),
('EMP7', 'Madubashana', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Manager', NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `PID` varchar(255) NOT NULL,
  `CID` varchar(255) DEFAULT NULL,
  `Projectname` varchar(255) DEFAULT NULL,
  `Location` varchar(255) DEFAULT NULL,
  `Startdate` varchar(255) DEFAULT NULL,
  `Enddate` varchar(255) DEFAULT NULL,
  `BOQ` varchar(50) DEFAULT NULL,
  `Cost` int(11) DEFAULT NULL,
  `Status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`PID`, `CID`, `Projectname`, `Location`, `Startdate`, `Enddate`, `BOQ`, `Cost`, `Status`) VALUES
('PID1', 'CID1', NULL, NULL, NULL, NULL, NULL, NULL, 0),
('PID2', 'CID1', 'aa', 'bb', 'Jul 3, 2020', 'Jul 2, 2020', '2134', 12345, 1);

-- --------------------------------------------------------

--
-- Table structure for table `project_assign`
--

CREATE TABLE `project_assign` (
  `RecordID` varchar(255) NOT NULL,
  `PID` varchar(255) DEFAULT NULL,
  `EmployeeID` varchar(255) DEFAULT NULL,
  `Startdate` varchar(50) DEFAULT NULL,
  `Enddate` varchar(50) DEFAULT NULL,
  `Position` varchar(50) DEFAULT NULL,
  `Status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `project_assign`
--

INSERT INTO `project_assign` (`RecordID`, `PID`, `EmployeeID`, `Startdate`, `Enddate`, `Position`, `Status`) VALUES
('Record1', 'PID1', 'EMP1', 'Jul 10, 2020', 'Jul 4, 2020', 'Labourer', 1),
('Record2', 'PID1', 'EMP2', 'Jul 3, 2020', 'Jul 4, 2020', 'Supervisor', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `EmployeeID` varchar(225) NOT NULL,
  `Username` varchar(50) DEFAULT NULL,
  `Password` varchar(50) DEFAULT NULL,
  `Position` varchar(50) DEFAULT NULL,
  `Status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`EmployeeID`, `Username`, `Password`, `Position`, `Status`) VALUES
('EMP1', '234', '234', 'Supervisor', 1),
('EMP6', 'pasindu', '123', 'Supervisor', 1),
('EMP7', 'pasindum', '123', 'Manager', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendence`
--
ALTER TABLE `attendence`
  ADD PRIMARY KEY (`RecordID`),
  ADD KEY `PID` (`PID`),
  ADD KEY `EmployeeID` (`EmployeeID`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`CID`);

--
-- Indexes for table `empleaves`
--
ALTER TABLE `empleaves`
  ADD PRIMARY KEY (`RecordID`),
  ADD KEY `EmployeeID` (`EmployeeID`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`EmployeeID`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`PID`),
  ADD KEY `CID` (`CID`);

--
-- Indexes for table `project_assign`
--
ALTER TABLE `project_assign`
  ADD PRIMARY KEY (`RecordID`),
  ADD KEY `PID` (`PID`),
  ADD KEY `EmployeeID` (`EmployeeID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`EmployeeID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendence`
--
ALTER TABLE `attendence`
  MODIFY `RecordID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `empleaves`
--
ALTER TABLE `empleaves`
  MODIFY `RecordID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendence`
--
ALTER TABLE `attendence`
  ADD CONSTRAINT `attendence_ibfk_1` FOREIGN KEY (`EmployeeID`) REFERENCES `employees` (`EmployeeID`),
  ADD CONSTRAINT `attendence_ibfk_2` FOREIGN KEY (`PID`) REFERENCES `projects` (`PID`),
  ADD CONSTRAINT `attendence_ibfk_3` FOREIGN KEY (`EmployeeID`) REFERENCES `employees` (`EmployeeID`);

--
-- Constraints for table `empleaves`
--
ALTER TABLE `empleaves`
  ADD CONSTRAINT `empleaves_ibfk_1` FOREIGN KEY (`EmployeeID`) REFERENCES `employees` (`EmployeeID`) ON DELETE CASCADE;

--
-- Constraints for table `projects`
--
ALTER TABLE `projects`
  ADD CONSTRAINT `projects_ibfk_1` FOREIGN KEY (`CID`) REFERENCES `clients` (`CID`) ON DELETE CASCADE;

--
-- Constraints for table `project_assign`
--
ALTER TABLE `project_assign`
  ADD CONSTRAINT `project_assign_ibfk_1` FOREIGN KEY (`PID`) REFERENCES `projects` (`PID`),
  ADD CONSTRAINT `project_assign_ibfk_2` FOREIGN KEY (`EmployeeID`) REFERENCES `employees` (`EmployeeID`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`EmployeeID`) REFERENCES `employees` (`EmployeeID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
