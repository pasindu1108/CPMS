/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ServiceLayer;

import DataBaseLayer.DataBaseConnection;
import static com.sun.corba.se.impl.util.Utility.printStackTrace;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
public class StockService {
    
    private DataBaseConnection con;
    
    
    //get project id to combo box
     public ResultSet getProjID() {
        con = DataBaseConnection.getSingleConnection();
        String query = "SELECT PID FROM Construction.db_accessadmin.project1";
        ResultSet result = con.Search(query);
        
        return result;
    }
     //get supplier id to combo box
     public ResultSet getSupID() {
        con = DataBaseConnection.getSingleConnection();
        String query = "SELECT SID FROM Construction.db_accessadmin.supplier";
        ResultSet result = con.Search(query);
        
        return result;
    }
     
    //get itemcode to combo box
     public ResultSet getItemCode() {
        con = DataBaseConnection.getSingleConnection();
        String query = "SELECT ItemCode FROM Construction.db_accessadmin.Inventory1";
        ResultSet result = con.Search(query);
        
        return result;
    }
    
    public boolean validate(String projid, String itemcode, String itemname, String qty, String supid, String unitprice, GUI.Inventory_Management inven){
        if(projid.equals("") || itemcode.equals("") || itemname.equals("") || qty.equals("") || supid.equals("") || unitprice.equals("")){
                JOptionPane.showMessageDialog(inven, "One or more fields are empty", "Error", JOptionPane.ERROR_MESSAGE);
                
                
                return false;
        }
        
        else
        return true;
    }
    
    public boolean validate2(String projid, String itemcode, String itemname, String qty, String supid, String unitprice, GUI.Manage_Inventory invent){
        if(projid.equals("") || itemcode.equals("") || itemname.equals("") || qty.equals("") || supid.equals("") || unitprice.equals("")){
                JOptionPane.showMessageDialog(invent, "One or more fields are empty", "Error", JOptionPane.ERROR_MESSAGE);
        
                return false;
        }
        else
        return true;
    }
    
    
    
     //fetch eid 
     public String fetchID() {
        con = DataBaseConnection.getSingleConnection();
        String newID = "";
        String id = "I00";
        int temp;
        String query = "SELECT TOP 1 ItemCode FROM Construction.db_accessadmin.Inventory1 ORDER BY ItemCode DESC";
        ResultSet result = con.Search(query);
        try {

            result.next();
            id = result.getString("ItemCode");
            id = id.substring(1);

            int i = 0;
            while (id.charAt(i) == '0') {
                i++;
            }

            // Convert str into StringBuffer as Strings 
            // are immutable. 
            StringBuffer sb = new StringBuffer(id);

            // The  StringBuffer replace function removes 
            // i characters from given index (0 here) 
            sb.replace(0, i, "");
            id = sb.toString();
            temp = Integer.parseInt(id) + 1;

            for (i = 0; i < (5 - Integer.toString(temp).length()); i++) {
                newID = newID + "0";
            }
            newID = "I" + newID + temp;

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return newID;
    }
    
    /* making a array to assign items
     public ArrayList<User> userList(Models.Stock st, GUI.Stock_Management sm){
         ArrayList<User> userList =new ArrayList<>();
         con = DataBaseConnection.getSingleConnection();
          String query="SELECT * FROM Inventory1 WHERE Name='"+st.getItemname()+"'";
     }
     
*/
  
     public void insertNewInventory(Models.Stock inventory , GUI.Inventory_Management Inv) {
        
        con = DataBaseConnection.getSingleConnection();
        String query = "INSERT INTO Construction.db_accessadmin.Inventory1 VALUES('"+inventory.getItemcode()+"','"+inventory.getProjid()+"','"+inventory.getItemname()+"','"+inventory.getQty()+"','"+inventory.getRdate()+"','"+inventory.getSupid()+"','"+inventory.getUnitprice()+"')";
        boolean answer = con.Insert(query);
        if(answer == true)
            JOptionPane.showMessageDialog(Inv, "Successfully inserted", "Info", JOptionPane.INFORMATION_MESSAGE); 
        else
            JOptionPane.showMessageDialog(Inv, "Could not insert", "Error", JOptionPane.ERROR_MESSAGE); 
        
        
    }
     
     public void updateInventory(Models.Stock invent, GUI.Manage_Inventory inv){
    con = DataBaseConnection.getSingleConnection();
        
        String query = "UPDATE Construction.db_accessadmin.Inventory1 SET Itemcode='"+invent.getItemcode()+"', Name='"+invent.getItemname()+"',QTY='"+invent.getQty()+"',IDate='"+invent.getRdate()+"',SID='"+invent.getSupid()+"',unitPrice='"+invent.getUnitprice()+"' where PID ='"+invent.getProjid()+"'";
        boolean answer = con.Update(query);
        if(answer == true)
            JOptionPane.showMessageDialog(inv, "Successfully updated", "Info", JOptionPane.INFORMATION_MESSAGE); 
        else
            JOptionPane.showMessageDialog(inv, "Could not update", "Error", JOptionPane.ERROR_MESSAGE); 
     
    }
     
     public void deleteInventory(String PID){
        con = DataBaseConnection.getSingleConnection();
        String query = "DELETE FROM Construction.db_accessadmin.Inventory1 WHERE PID='"+PID+"'";
        con.Delete(query);
        
        
    }
     
     public ResultSet getInventoryDetails() {
        con = DataBaseConnection.getSingleConnection();
        String query = "SELECT * FROM Construction.db_accessadmin.Inventory1";
        
        ResultSet result1 = con.Search(query);
        
   
        return result1;
    }
    public ResultSet getMachineDetalis(){
        con = DataBaseConnection.getSingleConnection();
        String query = "SELECT * FROM Construction.db_accessadmin.machinery";
        
        ResultSet result1 = con.Search(query);
        
   
        return result1;
    }
     
    public ResultSet searchInventory(String pid) {
        con = DataBaseConnection.getSingleConnection();
        String query = "SELECT * FROM Construction.db_accessadmin.Inventory1 WHERE PID='" + pid + "'";
        ResultSet result = con.Search(query);
        return result;
    }
    
    public ResultSet searchInventoryTable() {
        con = DataBaseConnection.getSingleConnection();
        String query = "SELECT * FROM Construction.db_accessadmin.Inventory1";
        ResultSet result = con.Search(query);
        return result;
    }
    
    
}
