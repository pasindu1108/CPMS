/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ServiceLayer;

import DataBaseLayer.DataBaseConnection;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author WWW
 */
public class IssuedNoteService {
     private DataBaseConnection con;
    
     //get project id to combo box
     public ResultSet getProjID() {
        con = DataBaseConnection.getSingleConnection();
        String query = "SELECT PID FROM Construction.db_accessadmin.project1";
        ResultSet result = con.Search(query);
        
        return result;
    }
     
    //get project id to combo box
     public ResultSet getItemcode() {
        con = DataBaseConnection.getSingleConnection();
        String query = "SELECT ItemCode FROM Construction.db_accessadmin.Inventory1";
        ResultSet result = con.Search(query);
        
        return result;
    }
    
    public boolean validate(String projid,String gstatus,String itemcode,String qty,String grnNo,String remarks,String resperson, GUI.Inventory_Management inv){
        if(qty.equals("") || grnNo.equals("") || remarks.equals("") || resperson.equals("")){
                JOptionPane.showMessageDialog(inv, "One or more fields are empty", "Error", JOptionPane.ERROR_MESSAGE);
        
                return false;
        }
        else
        return true;
    }
}
 