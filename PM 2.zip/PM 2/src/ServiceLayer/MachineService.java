/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ServiceLayer;

import DataBaseLayer.DataBaseConnection;
import java.sql.ResultSet;
import static com.sun.corba.se.impl.util.Utility.printStackTrace;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public class MachineService {
     private DataBaseConnection con;
    
    
    //get project id to combo box
     public ResultSet getProjID() {
        con = DataBaseConnection.getSingleConnection();
        String query = "SELECT PID FROM Construction.db_accessadmin.project1";
        ResultSet result = con.Search(query);
        
        return result;
    }
     
    public boolean validate(String machineid, String mtype, String mqty, String loadcapacity, String projid, String plocation, GUI.Inventory_Management inv){
        if(machineid.equals("") || mtype.equals("") || mqty.equals("") || loadcapacity.equals("") || projid.equals("") || plocation.equals("")){
                JOptionPane.showMessageDialog(inv, "One or more fields are empty", "Error", JOptionPane.ERROR_MESSAGE);
        
                return false;
        }
        else
        return true;
    }
    
   
    public String fetchID2() {
        con = DataBaseConnection.getSingleConnection();
        String newID = "";
        String id = "M00";
        int temp;
        String query = "SELECT TOP 1 machineID FROM Construction.db_accessadmin.machinery ORDER BY machineID DESC";
        ResultSet result = con.Search(query);
        try {

            result.next();
            id = result.getString("machineID");
            id = id.substring(1);

            int i = 0;
            while (id.charAt(i) == '0') {
                i++;
            }

            // Convert str into StringBuffer as Strings 
            // are immutable. 
            StringBuffer sb = new StringBuffer(id);

            // The  StringBuffer replace function removes 
            // i characters from given index (0 here) 
            sb.replace(0, i, "");
            id = sb.toString();
            temp = Integer.parseInt(id) + 1;

            for (i = 0; i < (5 - Integer.toString(temp).length()); i++) {
                newID = newID + "0";
            }
            newID = "M" + newID + temp;

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return newID;
    }
    
     public void insertNewMachinery(Models.Machinery machine , GUI.Inventory_Management Inv) {
        
        con = DataBaseConnection.getSingleConnection();
        String query = "INSERT INTO Construction.db_accessadmin.machinery VALUES('"+machine.getMachineid()+"','"+machine.getMtype()+"','"+machine.getMqty()+"','"+machine.getLoadcapacity()+"','"+machine.getProjid()+"','"+machine.getPlocation()+"')";
        boolean answer = con.Insert(query);
        if(answer == true)
            JOptionPane.showMessageDialog(Inv, "Successfully inserted", "Info", JOptionPane.INFORMATION_MESSAGE); 
        else
            JOptionPane.showMessageDialog(Inv, "Could not insert", "Error", JOptionPane.ERROR_MESSAGE); 
        
        
    }
     
     public void updateMachinery(Models.Machinery machine , GUI.Manage_Inventory inv){
    con = DataBaseConnection.getSingleConnection();
        
        String query = "UPDATE Construction.db_accessadmin.machinery SET machine_type='"+machine.getMtype()+"', qty='"+machine.getMtype()+"',loadCapacity='"+machine.getLoadcapacity()+"',PID='"+machine.getProjid()+"',location='"+machine.getPlocation()+"' where machineID ='"+machine.getMachineid()+"'";
        boolean answer = con.Update(query);
        if(answer == true)
            JOptionPane.showMessageDialog(inv, "Successfully updated", "Info", JOptionPane.INFORMATION_MESSAGE); 
        else
            JOptionPane.showMessageDialog(inv, "Could not update", "Error", JOptionPane.ERROR_MESSAGE); 
     
    }
     
     public void deleteMachinery(String machineID){
        con = DataBaseConnection.getSingleConnection();
        String query = "DELETE FROM Construction.db_accessadmin.machinery WHERE machineID='"+machineID+"'";
        con.Delete(query);
        
        
    }
     
     public ResultSet getMachinerySummary() {
        con = DataBaseConnection.getSingleConnection();
        String query = "SELECT * from Construction.db_accessadmin.machinery ";
        ResultSet result1 = con.Search(query);
        
        
        return result1;
    }
     
    public ResultSet searchMachinery(String machineID) {
        con = DataBaseConnection.getSingleConnection();
        String query = "SELECT * FROM Construction.db_accessadmin.machinery WHERE machineID='" + machineID + "'";
        ResultSet result = con.Search(query);
        return result;
    }
}

