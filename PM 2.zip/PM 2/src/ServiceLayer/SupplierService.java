/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ServiceLayer;

import DataBaseLayer.DataBaseConnection;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;


public class SupplierService {
     private DataBaseConnection con;
     
      public boolean validate(String sid, String name, String type, String contact, String address, String email, GUI.Inventory_Management inv){
        if(sid.equals("") || name.equals("") || type.equals("") || contact.equals("") || address.equals("") || email.equals("")){
                JOptionPane.showMessageDialog(inv, "One or more fields are empty", "Error", JOptionPane.ERROR_MESSAGE);
        
                return false;
        }
        else
        return true;
    }
      
public String fetchID3() {
        con = DataBaseConnection.getSingleConnection();
        String newID = "";
        String id = "S00";
        int temp;
        String query = "SELECT TOP 1 SID FROM Construction.db_accessadmin.supplier ORDER BY SID DESC";
        ResultSet result = con.Search(query);
        try {

            result.next();
            id = result.getString("SID");
            id = id.substring(1);

            int i = 0;
            while (id.charAt(i) == '0') {
                i++;
            }

            // Convert str into StringBuffer as Strings 
            // are immutable. 
            StringBuffer sb = new StringBuffer(id);

            // The  StringBuffer replace function removes 
            // i characters from given index (0 here) 
            sb.replace(0, i, "");
            id = sb.toString();
            temp = Integer.parseInt(id) + 1;

            for (i = 0; i < (5 - Integer.toString(temp).length()); i++) {
                newID = newID + "0";
            }
            newID = "S" + newID + temp;

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return newID;
    }

public void insertNewSupplier(Models.Suppliers sup, GUI.Inventory_Management Inv) {
        
        con = DataBaseConnection.getSingleConnection();
        String query = "INSERT INTO Construction.db_accessadmin.supplier VALUES('"+sup.getSupid()+"','"+sup.getSupname()+"','"+sup.getStype()+"','"+sup.getContact()+"','"+sup.getAddress()+"','"+sup.getEmail()+"')";
        boolean answer = con.Insert(query);
        if(answer == true)
            JOptionPane.showMessageDialog(Inv, "Successfully inserted", "Info", JOptionPane.INFORMATION_MESSAGE); 
        else
            JOptionPane.showMessageDialog(Inv, "Could not insert", "Error", JOptionPane.ERROR_MESSAGE); 
        
        
    }
    
}
