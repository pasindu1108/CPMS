/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author WWW
 */
public class Machinery {
    String machineid;
    String mtype;
    double mqty;
    double loadcapacity;
    String projid;
    String plocation;

    public Machinery(String machineid, String mtype, double mqty, double loadcapacity, String projid, String plocation) {
        this.machineid = machineid;
        this.mtype = mtype;
        this.mqty = mqty;
        this.loadcapacity = loadcapacity;
        this.projid = projid;
        this.plocation = plocation;
    }

    public String getMachineid() {
        return machineid;
    }

    public String getMtype() {
        return mtype;
    }

    public double getMqty() {
        return mqty;
    }

    public double getLoadcapacity() {
        return loadcapacity;
    }

    public String getProjid() {
        return projid;
    }

    public String getPlocation() {
        return plocation;
    }

   
    
}
