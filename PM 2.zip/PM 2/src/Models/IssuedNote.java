/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author WWW
 */
public class IssuedNote {
    String projid;
    String gstatus;
    String itemcode;
    double qty;
    String grnNo;
    String remarks;
    String resperson;

    public IssuedNote(String projid, String gstatus, String itemcode, double qty, String grnNo, String remarks, String resperson) {
        this.projid = projid;
        this.gstatus = gstatus;
        this.itemcode = itemcode;
        this.qty = qty;
        this.grnNo = grnNo;
        this.remarks = remarks;
        this.resperson = resperson;
    }

    public String getProjid() {
        return projid;
    }

    public String getGstatus() {
        return gstatus;
    }

    public String getItemcode() {
        return itemcode;
    }

    public double getQty() {
        return qty;
    }

    public String getGrnNo() {
        return grnNo;
    }

    public String getRemarks() {
        return remarks;
    }

    public String getResperson() {
        return resperson;
    }
    
    
}
