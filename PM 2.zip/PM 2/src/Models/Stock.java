/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import java.sql.Date;

/**
 *
 * @author WWW
 */
public class Stock {
   String projid;
   String itemcode;
   String itemname;
   double qty;
   Date rdate;
   String supid;
   double unitprice;

    public Stock(String projid, String itemcode, String itemname, double qty, Date rdate, String supid, double unitprice) {
        this.projid = projid;
        this.itemcode = itemcode;
        this.itemname = itemname;
        this.qty = qty;
        this.rdate = rdate;
        this.supid = supid;
        this.unitprice = unitprice;
    }

    public String getProjid() {
        return projid;
    }

    public String getItemcode() {
        return itemcode;
    }

    public String getItemname() {
        return itemname;
    }

    public double getQty() {
        return qty;
    }

    public Date getRdate() {
        return rdate;
    }

    public String getSupid() {
        return supid;
    }

    public double getUnitprice() {
        return unitprice;
    }
   
   
   
}



