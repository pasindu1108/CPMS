/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author WWW
 */
public class Suppliers {
    String supid;
    String supname;
    String stype;
    String contact;
    String address;
    String email;

    public Suppliers(String supid, String supname, String stype, String contact, String address, String email) {
        this.supid = supid;
        this.supname = supname;
        this.stype = stype;
        this.contact = contact;
        this.address = address;
        this.email = email;
    }

    public String getSupid() {
        return supid;
    }

    public String getSupname() {
        return supname;
    }

    public String getStype() {
        return stype;
    }

    public String getContact() {
        return contact;
    }

    public String getAddress() {
        return address;
    }

    public String getEmail() {
        return email;
    }
    
    
}
